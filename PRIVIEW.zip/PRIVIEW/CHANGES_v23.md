# v23 노출 위험 모듈 v9.6 반영

v22 에서 노출 모듈(`exposure_pipeline/`)만 v9.6 으로 바꾸고, 대시보드가 v9.6 의 새 산출 상태를 올바르게 다루도록 `app.py` 를 고쳤습니다.
식별·집계·가명처리 모듈과 대시보드 화면(HTML·CSS·JS)은 v22 와 같습니다.

## 교체한 파일 (노출 v9.6 원본 그대로)

- `exposure_pipeline/metrics.py`, `exposure_stage.py`, `service.py`, `__init__.py`, `CHANGES.md`, `README.md`
- 나머지 노출 파일, 학습 RF 모델(`rf_model.joblib`), 보정 자료(`calibration_holdout.csv`)는 v9.5 와 바이트 단위로 같아서 그대로 둠
- `tests/exposure/test_presence_and_ee.py`: v9.6 테스트로 교체. 모델 경로만 대시보드 폴더 구조(`exposure_pipeline/`)에 맞춤

v9.6 의 변경: 계산할 수 없는 성분을 0 대신 `NaN` + 상태(수치·확정·비적용)로 남김, 평가 누락 보고, 확정 속성은 우선 검토 대상.
자세한 내용은 `exposure_pipeline/CHANGES.md` 와 노출 패키지의 `REFACTORING_v9.6.md`.

## app.py 수정 (v9.6 의 NaN·상태를 다루기 위해)

| 위치 | v22 동작 (v9.6 과 함께 쓰면) | v23 |
|---|---|---|
| `_json_safe` | numpy NaN 이 그대로 나가 결과 JSON 이 깨짐 | NaN → null |
| `_run_exposure` | 상태 정보 없음, 점수 NaN 포함 | `determined_attributes`·`unscored_attributes`·`status_counts` 추가, NaN 점수 제외 |
| `_build_attribute_risk_report` (2단계 입력) | NaN → L (확정 속성이 저위험으로 들어감) | 확정 → 노출(분포) H (v9.6 "우선 검토"), 비적용 → L, NaN 점수는 넣지 않음 |
| 재평가 `reassess_fn` | 처리 후 NaN → L (낮아진 것으로 오판) | NaN 이면 H 유지 + 사유 기록 ("확정(우선 검토)" 또는 "비적용") |
| `_recommended_columns` | 확정 속성 누락 | 확정 속성을 추천 컬럼에 포함 |

## 실험 1 (B 엔진) 과의 관계

- PASS 판정(R_id·R_inf)은 노출 모듈을 쓰지 않으므로 결과가 바뀌지 않음.
- 실험 1 보조 기록인 EMD/Combo 만 노출 함수를 쓰며, v9.6 기준으로 값이 계산됨(확정·비적용이면 빈 값).

## 검증

- 전체 테스트 46개 통과 (기존 + 노출 v9.6 테스트)
- 유효값 1종 열(확정)을 넣은 샘플: JSON 에 NaN 없음, 확정 속성이 2단계 입력에서 노출(분포) H, 추천 컬럼에 포함
