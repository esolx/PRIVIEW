# v22 재가명처리 실험용 수정

위험평가 모듈(식별·집계·노출)과 대시보드 화면(HTML/CSS/JS)은 v21과 같습니다.

## 1. 강도별 결과 저장

재가명처리를 실행하면(대시보드, 실험 실행기 모두) 결과 폴더에 다음 파일이 생깁니다.

| 파일 | 내용 |
|---|---|
| `strength_search_log.csv` | 시도 1건 = 1행 (컬럼 × 기법 × 강도 단계). 시드, 변경률, 유용성 손실, 달성 여부, 기법 내 채택 단계, 최종 채택 여부, 축별(식별/집계/노출_분포/노출_외부연결) 처리 전 등급·처리 후 등급·처리 후 점수·오류 |
| `candidate_comparison.csv` | 후보 기법 1개 = 1행. 달성 여부, 채택 단계, 유용성 손실, 종합 점수, 시도/건너뜀/오류 수, 최종 채택 여부 |
| `strength_search_log.json` | 위 두 표 + 처리 요약 |
| `trials/<컬럼>/<기법>__<단계>.csv` | 그 시도의 처리본 (original, processed 두 열) |
| `reassessment/<컬럼>/<기법>__<단계>/trial_result.json` | 그 시도의 재평가 결과 (처리 전후 등급, 점수, 오류) |

- 처리 후 점수(`*_after_score`)는 실제로 재평가한 축(원래 H였던 축)에만 채워집니다. 나머지 축은 1단계 등급을 그대로 씁니다.
- 무변경 단계는 `skipped` 열에 "무변경 — 재평가 생략"으로 남습니다.

## 2. 목적 외 사용 없이 실행하는 실험 실행기 (`experiment.py`)

PDF 계획서와 목적 판정 없이 식별 · 집계 · 노출 → 통합 → 재가명처리(강도 탐색) → 처리 후 재평가 → 전후 비교를 실행합니다. 평가 함수는 `app.py`의 것을 그대로 불러 씁니다.

- `run_experiment(data, target_col, out_dir)`: 처음부터 끝까지
- `run_baseline(...)`: 처리 전 평가만 (여러 시드로 반복할 때 한 번만 실행)
- `run_repseudonymization(baseline_dir, out_dir)`: 저장된 처리 전 평가로 재가명처리 + 재평가

## 3. 재평가 오류 기록

강도 시도 중 재평가가 실패하면 그 축은 이전처럼 H로 채우되, 오류 내용을 남깁니다.

- `strength_search_log.csv`의 `*_error`, `has_error` 열
- 해당 시도 폴더의 `error.log` (전체 traceback)
- 실행 중 "재평가 오류 N건" 경고 출력

## 4. 시도별 시드

- `set_base_seed(42)`로 기본 시드를 정하면, 시도(컬럼, 기법, 단계)마다 `sha256(기본시드|컬럼|기법|단계)`로 시드를 만들어 그 시도 직전에 넣습니다.
- 컬럼을 추가하거나 순서를 바꿔도 같은 (컬럼, 기법, 단계)는 같은 처리본이 나옵니다.
- 기본 시드를 정하지 않으면 이전과 같이 무작위입니다. 대시보드 동작은 바뀌지 않습니다.
- 집계(`seed=42`), 노출(`bootstrap_seed=7`)은 각 모듈의 고정 시드를 그대로 씁니다.

## 5. 삭제

- `modules/pseudonymization_pipeline/dashboard_integration.py` 삭제. 대시보드·테스트 어디에서도 쓰지 않았고(패키지 `__init__` 재노출만 있었음), 노출 축을 항상 H로 고정하고 집계 구버전 API를 쓰는 이전 연결 코드였습니다. 현재 재평가는 `app.py`의 `run_repseudonymization_from_result()`가 담당합니다. `MODULE_SOURCES_v21.json`에서도 해당 항목을 뺐습니다.

## 그 외

- `app.py`: 재가명처리 핵심을 `run_repseudonymization_from_result()`로, 처리 후 재평가를 `reassess_dataframe()`로 분리 (대시보드 API는 그대로 사용)
- `AttributeRisk.errors` 필드 추가
- 대시보드 요약에 `reassessment_errors` 항목 추가
- `tests/test_trial_seed_and_log.py` 추가 (시드 재현성, 오류 기록, 저장 파일)
- `experiments/sample_small.csv`: COMPAS 샘플 120행 × 8열 (집계 타깃 `two_year_recid`)

## 검증

- 전체 테스트 36개 통과 (기존 31 + 신규 5)
- 샘플 120행으로 실험 실행기 전체 실행: `race`, `priors_count`가 노출(분포) H → 강도 탐색 9회 → 둘 다 M 달성, 노출 데이터셋 등급 M → L
- 대시보드 재가명처리·재평가 API 정상 동작, 강도별 파일 저장 확인
- 이 환경에는 Julia가 없어 식별 평가는 실패 기록까지만 확인했습니다 (오류가 시도마다 정상 기록됨). 실제 식별 수치는 Julia/CorrectMatch가 설치된 환경에서 확인해야 합니다.
