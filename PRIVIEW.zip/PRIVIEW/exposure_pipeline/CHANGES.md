# 수정 내역 (원본 대비)

원본 `exposure_pipeline` 패키지에서 아래 **6개 파일**이 수정되었습니다.
나머지 15개 모듈은 원본 그대로입니다.

수정: `config.py` · `column_mapping.py` · `pipeline.py` · `fp_control.py` ·
`metrics.py` · `exposure_stage.py`

---

## 1. `config.py` — 카테고리 키워드 & 비민감 프로토타입 보강

- **HEALTH 카테고리**: 건강검진 동의서(대한산업보건협회 서식)에서 추출한
  키워드 추가 — 체질량지수·허리둘레·공복혈당·총콜레스테롤·HDL/LDL콜레스테롤·
  트리글리세라이드·신사구체여과율·요단백·폐결핵·흉부질환·B형간염·가족력·
  과거력·흡연·음주량·운동여부·직무스트레스개인표·검진일자·종합소견 등.
- **CRIMINAL_RECORD 카테고리**: 범죄경력 회보서(경찰청 서식)에서 추출한
  키워드 추가 — 범죄경력회보서·범죄경력조회·회보서·수사경력자료·죄명·
  처분결과·처분관서·선고일자·자격정지·과료·구류·기소·불기소·무혐의·형실효
  및 영문(disposition·prosecution·acquittal·detention 등).
- **NEGATIVE_CATEGORY(비민감) 프로토타입**: 10개 → 28개로 확충.
  흔한 비민감 컬럼 표현(플래그·상태코드·외래키·비율·배치ID 등)을 채워
  비민감 유사도를 끌어올림 → 코사인 상대 마진 정확화(오탐 감소).

이 방식(config 직접 수정)은 컬럼명 매핑(0단계)뿐 아니라 SBERT/코사인
프로토타입까지 함께 강화하므로, 이름이 축약돼도 유사도 단계에서 탐지 가능.

## 2. `column_mapping.py` — 강한/약한 매핑 구분

- `MappingHit`에 `full_name_match` 필드와 `is_strong` 속성 추가.
- **강한 매칭**(override / exact / token)만 0단계 앵커로 확정.
- **약한 매칭**(affix / substring, 신뢰도 0.60~0.75)은 0단계에서 확정하지
  않고 후보로 남겨 뒷단계(코사인·정규식·SBERT·RF)로 넘김.
  → 'health_check_flag'의 'health' 파편 매칭이 무조건 확정되던 문제 완화.
  token은 강함 유지(‘purchase_amount’ 등 정상 컬럼 보호, 회귀 없음).

## 3. `pipeline.py` — 캐스케이드 + SBERT 양방향 재검증

- **약한 매핑 후보 처리**: 강한 앵커만 0단계 확정, 약한 매핑은 뒷단계로.
- **비대칭 코사인 마진**: `sim_margin_min` 0.02→0.06(비법정 오탐 방어),
  단 법정은 `sim_margin_legal=0.02`로 완화 적용(법정 Recall 보호).
- **SBERT 양방향 재검증(cross-check)** 신규 — 확정을 뒤집지 않고 검수 큐로:
  - (a) 오탐 재확인: 민감 확정인데 SBERT가 강하게 비민감 → 검수
  - (b) 미탐 재확인: 비민감 확정인데 SBERT가 강하게 민감 → 검수
  - (c) 법정 재확인: 비법정인데 SBERT legal_score 높음 → 검수
  - config: `sbert_crosscheck`(기본 True), `sbert_disagree_margin`,
    `sbert_missed_margin`, `sbert_legal_margin`.
  - 주의: 임계값은 실제 sentence-transformers 스케일 기준. 미설치 시
    해시 폴백이라 마진이 작아 잘 발동 안 함 → 운영 전 설치 권장.

## 4. `fp_control.py` — 구조 가드 확충

- 값 형식(정규식)이 없어 값검증으로 오탐을 못 거르던 카테고리에
  최소 카디널리티 가드 추가: HEALTH·IDEOLOGY_BELIEF·POLITICAL_OPINION·
  UNION_PARTY·RACE_ETHNICITY (`min_unique`: 2).
  법정은 위반 시에도 강등이 아니라 WEAK+검수로 보냄(법정 보호 유지).

## 5. `metrics.py` — 세분성(granularity) 보정

- 기존 `granularity_risk`는 `rarity.max()`라 N이 크면 항상 ~1.0 포화되어
  위험/안전이 구분 안 되는 문제(당위성 부족).
- **k-익명성 단일 지표로 변경**: 크기가 k 미만인 동치류(희귀 조합)에 속한
  레코드의 '비율'을 반환. 분포 전체를 반영해 위험/안전이 실제로 갈림.
  - `granularity_risk(qi_frame, k=5)` — `k`만 조정 가능.
  - 구버전 `1−freq/N` 최댓값(doc/max) 방식은 재식별과 사실상 동일하고
    유일 조합 하나로 포화되어 **제거**했다(필요 시 재추가 가능).
  - 히트맵·개별뷰·스칼라·그래프 전부 이 단일 k-익명 값을 공유한다.

## 6. `exposure_stage.py` — H/M/L 밴딩 제거 → 지표 선택 프레임워크로 대체

> ⚠️ **이후 갱신됨(CHANGES_HML.md 참고).** 아래는 당시 이력이다. 현재는 (속성×
> 지표) 행렬(분석용)은 그대로 두되, 그 위에 데이터셋 H/M/L '판정' 층을 다시
> 얹었다(max(내부,외부)→ρ→등급·top-k). 또한 지표 메타데이터의 '장단점'
> 서술은 삭제되어 `describe_metrics()`는 지표 설명만 출력한다.

지표들은 단위·의미가 달라 하나의 최종값으로 합치면(덧셈·곱셈 모두) 근거가
약해진다. 그래서 **합치지 않고** (속성×지표) 행렬 하나만 최종 산출로 두고,
이용자가 지표를 골라 해석하도록 바꿨다.

- **제거**: `risk_bands()`, `_natural_breaks_2()`, `band_matrix()`(지표별
  `*_band` 열), 그리고 `run_exposure_metrics`가 반환하던 단일 대표값 요약
  (`summary`의 `internal_expo`/`external_expo`/`R_s`)까지 전부 삭제.
  → High/Medium/Low 고정 등급은 더 이상 제공하지 않는다.
- **추가(`metrics.py`)**: `METRIC_SPECS` — 지표별 메타데이터(축 내부/외부,
  측정 내용, 장점, 단점, 참고 임계값). `internal_metrics()`/`external_metrics()`.
- **추가(`exposure_stage.py`)**:
  - `describe_metrics()` — 지표 특징·장단점·참고 임계값을 텍스트로.
  - `select_metrics(matrix, keys=…, axis=…)` — 이용자가 고른 지표만 부분 행렬로.
  - `flag_by_reference(matrix)` — 지표별 참고 임계값을 넘는 속성 목록(등급이
    아니라 '한 번 더 볼' 포인터. 임계값은 데이터에 맞게 조정 가능).
  - `render_heatmap(matrix, out_path)` — 내부=파랑/외부=빨강 히트맵 PNG(옵션,
    matplotlib 없으면 자동 생략). 한글 폰트 자동 탐지.
- `run_exposure_metrics`/`run_from_detection` 반환은 이제
  `{roles, qi_dropped, matrix}` (summary 없음).

## 7. `metrics.py` — combo(복합 민감도) 식별자 포화 버그 수정

증상: 합성 데모에서 `combo`가 모든 민감속성에서 1.0으로 동일하게 나옴.

원인: `access_ip`·`ADID`처럼 near-unique(고유값 비율≈1.0) 컬럼이 민감으로
탐지되면, nMI가 1.0으로 포화된다(고유키는 무엇이든 '결정'하므로
I(A;키)=H(A), min=H(A) → nMI=1). noisy-OR라 이 1.0 하나가 다른 모든 속성의
combo까지 1.0으로 오염시킴 → 전부 1.0.

수정: `composite_sensitivity(..., max_unique_ratio=0.9)` — 고유값 비율이
임계를 넘는 식별자형 컬럼은 얽힘 계산에서 상대·대상 모두 제외하고 combo=0.
(그 컬럼의 위험은 재식별 축 granularity·EE에서 잡힌다.) `filter_qi_by_
cardinality`(QI)·k-anon(granularity)와 같은 방어를 combo에도 맞춘 것.
헬퍼 `identifier_like_columns()` 추가. 진짜 종속(예: income=f(disease))은
여전히 combo≈1.0으로 정상 검출됨(가짜 포화만 제거).

## 8. `exposure_stage.py` — 시각화 2종 추가(선택, matplotlib)

- `render_heatmap(matrix)` — (속성×지표) 히트맵 PNG(내부=파랑/외부=빨강).
- `integrated_risk(matrix)` + `render_risk_curve(...)` — 통합 위험 분포 곡선.
  ⚠️ **개편됨(CHANGES_HML.md).** 현재는 Critical/High/Middle/Low 4밴드 대신
  임계선 τ·초과 속성 강조·데이터셋 H/M/L 등급 배지 방식으로 그린다. 통합 위험
  = max(내부, 외부)로 산출하는 점은 동일. CJK 폰트 자동 탐지.
  ※ granularity(레코드 수준)는 QI 조합만의 함수라 모든 민감속성에서 값이
    동일한 게 정상이다(데이터셋 1개 스칼라로 읽을 것).

---

## 함께 제공되는 보조 파일 (패키지 밖)

- `evaluate_dataset.py` — 임의 CSV(+정답)로 탐지 성능(Recall/Precision/F1/
  카테고리 정확도) 측정하는 실행 스크립트.
- `extra_terms_health_criminal.py` — config를 수정하지 않고 컬럼명 매핑만
  즉시 보강하는 확장 사전(대안. 원본 보존하며 실험용).
