# exposure_pipeline — 노출 위험도 평가 파이프라인 (민감정보 탐지 파트)

원본 단일 파일(`exposure_pipeline_all_2.py`, 3172줄)을 **기능별 13개 모듈**로
분리하고, 합성데이터 생성·내보내기(`synth.py`)를 추가한 리팩토링판이다.
탐지 로직 자체는 원본과 100% 동일하다.

## 실행
```bash
pip install scikit-learn pandas numpy scipy       # 필수
pip install sentence-transformers kiwipiepy nltk   # 권장(미설치 시 TF-IDF/규칙 폴백)

python -m exposure_pipeline        # 데모(clean 셋)
python run_synth.py                # clean + hard 셋 → out/*.csv
```

## 모듈 구성 (의존성 순서)
| 모듈 | 역할 |
|---|---|
| `config.py` | 카테고리(법정 9 + 비법정 9) 정의·정규식·가중치. 단일 진실 공급원 |
| `sensitivity_ref.py` | 논문3(Schomakers 2019) 지각 민감도 참조표 — 비법정 전용 |
| `column_mapping.py` | 0단계 칼럼명 매핑 테이블(가장 강한 신호) |
| `preprocess.py` | 형태소/토큰화·NER·keep/ignore 전처리 |
| `features.py` | 칼럼 프로파일링·구조특징·약라벨·부트스트랩 학습셋 |
| `tfidf_rf.py` | 1단계 TF-IDF + RandomForest |
| `threshold.py` | Recall 우선 임계값·이중 임계값(회색지대) |
| `sbert_sim.py` | 2단계 SBERT/TF-IDF 프로토타입 유사도(구제) |
| `fp_control.py` | 5층 오탐 방어(제외·값검증·구조가드·증거등급·피드백) |
| `risk_weight.py` | 위험도 가중치. 법정 1.5 고정 / 비법정 SV_adjusted 5단계 |
| `pipeline.py` | 0~2단계 캐스케이드 + Track 라우팅 |
| `cassed_lite.py` | **[신규·하이브리드]** 값 기반 Track B 탐지(가제티어+정규식)·다중라벨·파인튜닝 스캐폴드 |
| `synth.py` | 합성데이터 생성·CSV 내보내기·지표 |
| `demo.py` | 데모 진입점 |

## 파이프라인 흐름
```
데이터프레임
 → 칼럼 프로파일링 → 전처리(keep/ignore)
 → [0단계] 칼럼명 매핑(앵커)
 → [1단계] TF-IDF 코사인 유사도            (RF 제거, 코사인 단독)
 → [2단계] 정규표현식 값 스캔              (값 형식 매칭 = 주 탐지경로)
 → [3단계] SBERT 구제(1·2 잔여분만)
 → [4단계] RandomForest 경계 보정(맨 마지막; 확정 탐지 못 뒤집음, 잔여분만 승격)
 → FP 방어 5층
 → 법정 여부 → Track A(법정) / Track B(비법정)
 → 위험도 가중치: A=1.5 고정 / B=(1−SV_adjusted) 5단계
 → [Track B 강화·하이브리드] cassed_lite.value_rescue()  ← 신규
 → [구현됨] metrics.py + exposure_stage.py (EMD·Coverage·복합민감도·EE매칭·세분성)
```

## Track B 탐지 강화 — 하이브리드(CASSED-lite)

Track B(비법정)의 약점은 알고리즘이 아니라 **신호 부재**다. 소득·학력·직업·
소비 등 일부 비법정 속성은 값이 일반적이라 이름·정규식만으로 자주 놓치고, 실제 기업 DB처럼
**컬럼명이 축약·오도되면 0단계 이름 매핑이 통째로 실패**한다(CASSED가 지적한
문제). 그래서 A 방식을 복제해도 소용없고(신호가 없음), CASSED를 통째로
도입하기엔 택소노미 불일치·학습 비용이 크다. 채택한 절충:

1. **(무학습·즉시) 값 기반 복구** = `cassed_lite.value_rescue()`. 닫힌 어휘
   가제티어(학력/혼인/직업 …) + config 정규식 값검증기를 **값에** 스캔해,
   이름이 실패해도 값만으로 Track B를 복구한다. **가산 후처리**라 기존
   캐스케이드·FP 방어·검수 큐를 건드리지 않는다. 값만 근거인 복구는
   `review_required=True`로 검수 큐행(Recall 우선).
2. **(다중라벨)** 한 컬럼이 여러 카테고리면 secondary로 기록(CASSED와 동일 철학).
3. **(3단계 자리)** `FinetunedCassedRescuer` — mpnet 위 다중라벨 헤드 스캐폴드.
   torch/학습가중치가 있으면 사용, 없으면 가제티어+코사인 폴백(현재 폴백).

검증(컬럼명을 opaque 코드로 바꿔 이름 신호를 죽인 셋, `run_hybrid.py`):

| 지표 | BEFORE(기존) | AFTER(+값 복구) |
|---|---|---|
| 탐지 Recall | 0.70 | **0.80** |
| 탐지 Precision | 0.875 | **0.889** |
| 카테고리 정확도 | 0.483 | 0.552 |

INCOME_ASSET(가제티어)·COMMUNICATION(정규식)을 값만으로 복구, 오탐 증가 없음.
남는 잔여(신용점수·구매액 같은 **맨 정수**)는 값 어휘가 없어 못 잡으며,
이는 3단계 파인튜닝 헤드가 target 한다.

## 논문(PPM-SACG, Li et al. 2025) 반영 범위
| 논문 요소 | 이 코드 | 비고 |
|---|---|---|
| §4.1 SV_entropy = 1−H/H_max (Eq.5) | ✅ `risk_weight.sv_entropy` | log2, 그대로 |
| §4.1 SV_preference (설문 100명) | 🔁 대체 | 재현 불가 → 논문3 참조표로 교체 |
| §4.1 SV_adjusted = w1·SVe + w2·SVref | ✅ `composite_sensitivity` | w1=.6, w2=.4 |
| §4.1 결측 평균/최빈 대치 | ⚠️ 부분 | 프로파일링 단계 처리, 논문식 대치는 미구현 |
| §4.2.1 k-means 초기 분류(τ=0.6) | ❌ 미구현 | 탐지를 매핑+RF+SBERT로 대체 |
| §4.2.2 FP-Growth 연관규칙 보정 | ❌ 미구현 | FP 방어 5층이 다른 방식으로 대체 |
| §4.3 상호정보(MI) 행렬·계층군집 | ❌ 미구현 | 이후 PMI 단계 예정 |
| §4.3 등급 Level 1~4 (높을수록 민감) | ✅ `sensitivity_level4/5` | 논문 §4.3 방향(1−SV)으로 구현 |

**방향(극성) 주의**: 논문은 Eq.1·Def2·§4.2.1에서 "SV 작을수록 민감",
§4.3 등급표에서 "값 클수록 민감(Level 4=[0.75,1])"으로 **자체 모순**이 있다.
(논문 Table 7 Vehicle_ID 규제 0.16 → Table 10 등급 0.84 = 1−0.16 으로 뒤집힘.)
따라서 "논문 그대로"도 1−SV 뒤집기를 요구한다. 이 코드는
`sensitivity_level5(sv) = grade5(1 − sv)` 로 정확히 그 뒤집기를 수행해,
최종 위험도 가중치를 Track A(1.5)와 같은 "높을수록 위험" 방향으로 통일한다.
